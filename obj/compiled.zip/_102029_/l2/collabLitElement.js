"use strict";
/// <mls fileReference="_102029_/l2/collabLitElement.ts" enhancement="_102027_/l2/enhancementLit"/>
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CollabLitElement = void 0;
exports.getMessageKey = getMessageKey;
var lit_1 = require("lit");
var decorators_js_1 = require("lit/decorators.js");
var collabState_js_1 = require("/_102029_/l2/collabState.js");
/**
 * Class extending LitElement with CollabState functionality.
 */
var CollabLitElement = /** @class */ (function (_super) {
    __extends(CollabLitElement, _super);
    function CollabLitElement() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.globalVariation = collabState_js_1.globalState.globalVariation || 0;
        return _this;
    }
    CollabLitElement.prototype.createRenderRoot = function () {
        return this;
    };
    CollabLitElement.prototype.updated = function (changedProperties) {
        _super.prototype.updated.call(this, changedProperties);
        if (changedProperties.has('globalVariation') && changedProperties.get('globalVariation') !== undefined) {
            this.requestUpdate();
        }
    };
    CollabLitElement.prototype.getMessageKey = function (messages) {
        return getMessageKey(messages);
    };
    CollabLitElement.prototype.loadStyle = function (css) {
        if (!css)
            return;
        var tagName = this.tagName.toLowerCase();
        var alreadyAdded = document.head.querySelector("style#".concat(tagName));
        if (alreadyAdded) {
            alreadyAdded.textContent = css;
            return;
        }
        var style = document.createElement('style');
        style.id = tagName;
        style.textContent = css;
        document.head.appendChild(style);
    };
    __decorate([
        (0, decorators_js_1.property)({ type: Number })
    ], CollabLitElement.prototype, "globalVariation", void 0);
    return CollabLitElement;
}(lit_1.LitElement));
exports.CollabLitElement = CollabLitElement;
function getMessageKey(messages) {
    var keys = Object.keys(messages);
    if (!keys || keys.length < 1)
        throw new Error('Error Message not valid for international');
    var firstKey = keys[0];
    var lang = (document.documentElement.lang || '').toLowerCase();
    if (!lang)
        return firstKey;
    if (messages.hasOwnProperty(lang))
        return lang;
    var similarLang = keys.find(function (key) { return lang.substring(0, 2) === key; });
    if (similarLang)
        return similarLang;
    return firstKey;
}
