"use strict";
/// <mls fileReference="_102029_/l2/stateLitElement.ts" enhancement="_blank"/>
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.StateLitElement = void 0;
var collabLitElement_js_1 = require("/_102029_/l2/collabLitElement.js");
var collabState_js_1 = require("/_102029_/l2/collabState.js");
var isTrace = false;
/**
 * Base class for all components that need to interact with the shared state.
 */
var StateLitElement = /** @class */ (function (_super) {
    __extends(StateLitElement, _super);
    function StateLitElement() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // Controls the states associated with this object.
        // Once disconnected from the DOM, this web component will no longer receive notifications.
        // Paths can be modified dynamically during the web component's lifecycle. For example in attribute html:
        // name='{{globalStore.users.users[0].name}}'
        // ...
        // name='{{globalStore.users.users[1].name}}'
        _this.stateKeys = new Map();
        return _this;
    }
    StateLitElement.prototype.updateStateKeys = function (attributeName, paths) {
        var _this = this;
        // example: 
        // attributeName = "label"
        // paths = ["user.name", "user.age"]
        // example of use in html: label="User {{user.name}} is {{user.age}} users old"
        if (!attributeName || !paths || paths.length === 0) {
            console.warn('Invalid state key update attempt', { attributeName: attributeName, paths: paths });
            return;
        }
        for (var _i = 0, _a = this.stateKeys.keys(); _i < _a.length; _i++) {
            var key = _a[_i];
            if (key.startsWith("".concat(attributeName, "/"))) {
                this.stateKeys.delete(key);
                (0, collabState_js_1.unsubscribe)([key], this);
            }
        }
        paths.forEach(function (path, index) {
            var newItem = "".concat(attributeName, "/").concat(index, ";").concat(path);
            if (!_this.stateKeys.has(newItem)) {
                _this.stateKeys.set(newItem, false);
                _this.subscribeToState(newItem);
            }
        });
    };
    StateLitElement.prototype.subscribeToState = function (stateKey) {
        if (!this.stateKeys.get(stateKey)) {
            (0, collabState_js_1.subscribe)([stateKey], this);
            this.stateKeys.set(stateKey, true);
        }
    };
    StateLitElement.prototype.createRenderRoot = function () {
        return this;
    };
    StateLitElement.prototype.connectedCallback = function () {
        var _this = this;
        this._loadStartTime = performance.now();
        _super.prototype.connectedCallback.call(this);
        if (isTrace) {
            console.info("connectedCallback, subscribe fields: ".concat(Array.from(this.stateKeys.keys())));
        }
        this.stateKeys.forEach(function (isSubscribed, stateKey) {
            if (!isSubscribed) {
                _this.subscribeToState(stateKey);
            }
        });
        if (!window.collabPluginMonitor) {
            this.connectMonitoring();
        }
        var tagName = this.tagName.toLowerCase();
        window.collabPluginMonitor.reportStart(tagName, this._loadStartTime);
    };
    StateLitElement.prototype.disconnectedCallback = function () {
        var _this = this;
        _super.prototype.disconnectedCallback.call(this);
        this.stateKeys.forEach(function (isSubscribed, stateKey) {
            if (isSubscribed)
                (0, collabState_js_1.unsubscribe)([stateKey], _this);
            _this.stateKeys.set(stateKey, false);
        });
    };
    StateLitElement.prototype.firstUpdated = function (_changedProperties) {
        var _a;
        _super.prototype.firstUpdated.call(this, _changedProperties);
        this.stateKeys.forEach(function (_isSubscribed, stateKey) {
            var _a = stateKey.split(';'), path = _a[1];
            (0, collabState_js_1.notify)(path);
        });
        if (!window.collabPluginMonitor) {
            this.connectMonitoring();
        }
        var duration = performance.now() - ((_a = this._loadStartTime) !== null && _a !== void 0 ? _a : 0);
        var tagName = this.tagName.toLowerCase();
        window.collabPluginMonitor.reportDone(tagName, duration);
    };
    StateLitElement.prototype.updated = function (_changedProps) {
        var _this = this;
        _super.prototype.updated.call(this, _changedProps);
        var start = performance.now();
        requestAnimationFrame(function () {
            var _a, _b;
            var tagName = _this.tagName.toLowerCase();
            var renderTime = performance.now() - start;
            (_b = (_a = window.collabPluginMonitor) === null || _a === void 0 ? void 0 : _a.reportUpdate) === null || _b === void 0 ? void 0 : _b.call(_a, tagName, renderTime);
        });
    };
    /**
     * Handle state changes from IcaState.
     * @param key - The state key that changed, ex: 'users[0].name'
     * @param value - The new value of the state.
     */
    StateLitElement.prototype.handleIcaStateChange = function (key, value) {
        var _this = this;
        var isEqual = function (a, b) { return a === b || (typeof a === 'object' && JSON.stringify(a) === JSON.stringify(b)); };
        var ob1 = this;
        this.stateKeys.forEach(function (_isSubscribed, stateKey) {
            var _a = stateKey.split(';'), propName = _a[0], path = _a[1];
            propName = propName.split('/')[0]; // ex: name/0 , name/1 for composite dynamic keys
            if (path !== key || !ob1.hasAttribute(propName))
                return;
            var propValue = ob1["_".concat(propName)];
            if (!isEqual(value, propValue)) {
                ob1["_".concat(propName)] = value;
                _this.requestUpdate();
            }
        });
    };
    StateLitElement.prototype.connectMonitoring = function () {
        if (window.collabPluginMonitor)
            return;
        var monitor = {
            records: {},
            reportStart: function (name, _startTime) {
            },
            reportDone: function (name, duration) {
                var rec = this.getRec(name);
                rec.count++;
                rec.totalTime += duration;
                monitor.records[name] = rec;
            },
            reportUpdate: function (name, duration) {
                var rec = this.getRec(name);
                rec.updateCount++;
                rec.updateTime += duration;
                this.records[name] = rec;
            },
            getRec: function (name) {
                return this.records[name] || {
                    name: name,
                    count: 0,
                    totalTime: 0,
                    updateCount: 0,
                    updateTime: 0
                };
            },
            sts: function () {
                return Object.values(this.records).map(function (r) {
                    var _a, _b;
                    return ({
                        name: r.name,
                        count: r.count,
                        totalTime: parseFloat(r.totalTime.toFixed(2)),
                        avgTime: parseFloat((r.totalTime / r.count).toFixed(2)),
                        updateCount: (_a = r.updateCount) !== null && _a !== void 0 ? _a : 0,
                        updateTime: parseFloat(((_b = r.updateTime) !== null && _b !== void 0 ? _b : 0).toFixed(2)),
                        avgUpdateTime: r.updateCount ? parseFloat((r.updateTime / r.updateCount).toFixed(2)) : 0
                    });
                });
            }
        };
        window.collabPluginMonitor = monitor;
    };
    return StateLitElement;
}(collabLitElement_js_1.CollabLitElement));
exports.StateLitElement = StateLitElement;
