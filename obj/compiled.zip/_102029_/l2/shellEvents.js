"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AURA_CLOSE_ASIDE_EVENT = exports.AURA_OPEN_ASIDE_EVENT = exports.AURA_TOGGLE_ASIDE_EVENT = void 0;
exports.toggleAuraAside = toggleAuraAside;
exports.openAuraAside = openAuraAside;
exports.closeAuraAside = closeAuraAside;
/// <mls fileReference="_102029_/l2/shellEvents.ts" enhancement="_blank" />
exports.AURA_TOGGLE_ASIDE_EVENT = 'collab-aura:toggle-aside';
exports.AURA_OPEN_ASIDE_EVENT = 'collab-aura:open-aside';
exports.AURA_CLOSE_ASIDE_EVENT = 'collab-aura:close-aside';
function dispatchAuraShellEvent(eventName) {
    window.dispatchEvent(new CustomEvent(eventName));
}
function toggleAuraAside() {
    if (window.collabAuraShellControls) {
        window.collabAuraShellControls.toggleAside();
        return;
    }
    dispatchAuraShellEvent(exports.AURA_TOGGLE_ASIDE_EVENT);
}
function openAuraAside() {
    if (window.collabAuraShellControls) {
        window.collabAuraShellControls.openAside();
        return;
    }
    dispatchAuraShellEvent(exports.AURA_OPEN_ASIDE_EVENT);
}
function closeAuraAside() {
    if (window.collabAuraShellControls) {
        window.collabAuraShellControls.closeAside();
        return;
    }
    dispatchAuraShellEvent(exports.AURA_CLOSE_ASIDE_EVENT);
}
