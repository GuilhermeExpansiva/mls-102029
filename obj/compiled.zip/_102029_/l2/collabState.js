"use strict";
/// <mls fileReference="_102029_/l2/collabState.ts" enhancement="_blank"/>
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.globalState = void 0;
exports.getState = getState;
exports.setState = setState;
exports.subscribe = subscribe;
exports.unsubscribe = unsubscribe;
exports.notify = notify;
exports.initState = initState;
exports.getCollabStateInstance = getCollabStateInstance;
/**
 * Returns the value for a given state key.
 * @param key State key in dot notation.
 * @returns The value stored at the specified key, or undefined if not set.
 */
function getState(key) {
    return exports.globalState.globalStateManagment.getState(key);
}
/**
 * Updates the value for a given state key.
 * @param key State key in dot notation.
 * @param value Value to be stored.
 * @param systemChange Optional. If true, marks as a system-initiated change.
 */
function setState(key, value, systemChange) {
    exports.globalState.globalStateManagment.setState(key, value, systemChange);
}
/**
 * Subscribes a component to one or more state keys.
 * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
 * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
 * @param component - The subscribing component or callback function.
 */
function subscribe(keyOrKeys, component) {
    return exports.globalState.globalStateManagment.subscribe(keyOrKeys, component);
}
/**
 * Unsubscribe a component from a state key or keys.
 * @param keyOrKeys - The state key or keys.
 * @param component - The unsubscribing component.
 */
function unsubscribe(keyOrKeys, component) {
    return exports.globalState.globalStateManagment.unsubscribe(keyOrKeys, component);
}
/**
 * Notify subscribed components about a state change.
 * @param key - The state key that changed.
 */
function notify(key) {
    return exports.globalState.globalStateManagment.notify(key);
}
/**
 * Initializes a nested property in the global state object if it doesn't already exist.
 * If the property exists, it retains its current value without being overwritten.
 *
 * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
 * @param {*} value - The value to set if the property at the given path does not exist.
 */
function initState(path, value) {
    var keys = path.split('.');
    if (!exports.globalState._ica) {
        exports.globalState._ica = {};
    }
    var current = exports.globalState._ica;
    keys.forEach(function (key, index) {
        // changed
        if (!current[key]) {
            // Create an object or set the value if it doesn't exist
            current[key] = index === keys.length - 1 ? value : {};
        }
        else if (index === keys.length - 1 && typeof current[key] === 'object' && typeof value === 'object') {
            // Merge objects if both existing and new values are objects
            if (Array.isArray(current[key]) && Array.isArray(value)) {
                current[key] = __spreadArray([], value, true);
            }
            else {
                current[key] = __assign({}, value);
            }
        }
        current = current[key];
    });
}
var isTrace = false;
// Extend the Window interface
/*declare global {
  export interface Window {
    globalState: GlobalState;
    globalStateManagment: IcaState;
    globalVariation: number;
  }
}*/
exports.globalState = {};
function getCollabWindow() {
    if (window.parent && window.parent !== window && window.parent.globalStateManagment) {
        return window.parent;
    }
    return window;
}
window.getCollabWindow = getCollabWindow;
Object.defineProperty(exports.globalState, '_ica', {
    get: function () {
        return getCollabWindow()._ica;
    },
    set: function (v) {
        getCollabWindow()._ica = v;
    }
});
Object.defineProperty(exports.globalState, 'globalStateManagment', {
    get: function () {
        return getCollabWindow().globalStateManagment;
    },
    set: function (v) {
        getCollabWindow().globalStateManagment = v;
    }
});
Object.defineProperty(exports.globalState, 'globalVariation', {
    get: function () {
        return getCollabWindow().globalVariation;
    },
    set: function (v) {
        getCollabWindow().globalVariation = v;
    }
});
/**
 * Retrieves a nested property value from an object using a dot-separated path string.
 * Supports both nested object and array access with syntax like "a.b[3].c".
 *
 * Example usage:
 *   const obj = {
 *     products: [
 *       { name: "Apple" },
 *       { name: "Banana" },
 *     ],
 *     user: { name: "Alice" }
 *   };
 *
 *   getPathValue(obj, "user.name");         // returns "Alice"
 *   getPathValue(obj, "products[1].name");  // returns "Banana"
 *   getPathValue(obj, "products[2].name");  // returns undefined
 *   getPathValue(obj, "foo.bar");           // returns undefined
 *
 * @param {Object} obj - The root object to query.
 * @param {string} path - The dot-separated path string (supports array indices with brackets).
 * @returns {*} - The value found at the given path, or undefined if not found.
 */
function getPathValue(obj, path) {
    return (path || '').split('.').reduce(function (acc, part) {
        var _a;
        if (acc == null)
            return undefined;
        var arrayMatch = part.match(/^(\w+)\[(\d+)\]$/);
        if (arrayMatch) {
            var prop = arrayMatch[1];
            var index = parseInt(arrayMatch[2], 10);
            return (_a = acc[prop]) === null || _a === void 0 ? void 0 : _a[index];
        }
        return acc[part];
    }, obj);
}
/**
 * Sets a nested property value in an object using a dot-separated path string.
 * Supports creation of intermediate objects and arrays as needed.
 * Array indices can be specified using square brackets, e.g., "a.b[3].c".
 *
 * Example usage:
 *   const obj = {};
 *   setPathValue(obj, "user.addresses[0].city", "São Paulo");
 *   // obj is now: { user: { addresses: [ { city: "São Paulo" } ] } }
 *
 *   setPathValue(obj, "produtos[1].nome", "Banana");
 *   // obj.produtos[1] is now: { nome: "Banana" }
 *
 *   setPathValue(obj, "config.theme", "dark");
 *   // obj.config.theme === "dark"
 *
 * @param {Object} obj - The root object to modify.
 * @param {string} path - The dot-separated path string (supports array indices with brackets).
 * @param {*} value - The value to set at the given path.
 */
function setPathValue(obj, path, value) {
    var parts = (path || '').split('.');
    var last = parts.pop();
    if (!last)
        return;
    var lastObj;
    try {
        lastObj = parts.reduce(function (acc, part) {
            var match = part.match(/^(\w+)\[(\d+)\]$/);
            if (match) {
                var prop = match[1];
                var index = parseInt(match[2], 10);
                acc[prop] = acc[prop] || [];
                acc[prop][index] = acc[prop][index] || {};
                return acc[prop][index];
            }
            else {
                acc[part] = acc[part] || {};
                return acc[part];
            }
        }, obj);
    }
    catch (e) {
        var isArray = parts.some(function (p) { return /^\w+\[\d+\]$/.test(p); });
        initState(parts.join('.'), isArray ? [] : {});
        obj = exports.globalState._ica; // reload after initState
        lastObj = parts.reduce(function (acc, part) {
            var match = part.match(/^(\w+)\[(\d+)\]$/);
            if (match) {
                var prop = match[1];
                var index = parseInt(match[2], 10);
                acc[prop] = acc[prop] || [];
                acc[prop][index] = acc[prop][index] || {};
                return acc[prop][index];
            }
            else {
                acc[part] = acc[part] || {};
                return acc[part];
            }
        }, obj);
    }
    var lastIsArray = /^\w+\[\d+\]$/.test(last);
    if (lastIsArray && !Array.isArray(lastObj[last]))
        lastObj[last] = [];
    if (!lastIsArray && typeof lastObj[last] !== 'object')
        lastObj[last] = {};
    lastObj[last] = value;
}
/**
 * -----------
 * Class responsible for managing shared state.
 * -----------
 */
var CollabStateSingleton = /** @class */ (function () {
    function CollabStateSingleton() {
        //private stateMap: Map<string, any> = new Map(); // values of variables
        this.componentMap = new Map(); // subscribes
        this.history = [];
        this.notifyQueue = [];
        this.isNotifying = false;
    }
    CollabStateSingleton.prototype.getState = function (key) {
        var value = getPathValue(exports.globalState._ica, key);
        if (isTrace)
            console.info('getState key: ' + key + ' value=', value);
        return value;
    };
    CollabStateSingleton.prototype.setState = function (key, value, systemChange) {
        // Default systemChange to this.inNotify if not provided
        systemChange = systemChange !== null && systemChange !== void 0 ? systemChange : false;
        var oldValue = getPathValue(exports.globalState._ica, key);
        ;
        // this.stateMap.get(key);
        if (isTrace)
            console.info('setState key: ' + key + ' value=', value, ", oldValue=", oldValue);
        if (oldValue === value)
            return;
        // this.stateMap.set(key, value);
        var notifies = [key]; // array for notifies
        if (typeof value === "object" && value !== null) {
            var n = this.getNotifies(key, value);
            for (var _i = 0, n_1 = n; _i < n_1.length; _i++) {
                var path = n_1[_i];
                var oldValue_1 = getPathValue(exports.globalState._ica, path);
                var newValue = getPathValue(value, path.replace(key + ".", ""));
                if (oldValue_1 !== newValue)
                    notifies.push(path);
            }
        }
        setPathValue(exports.globalState._ica, key, value);
        this.logHistory(key, value, systemChange);
        this.notify(notifies);
    };
    /**
     * Given a base path and a newObj, finds all nested paths that match
     * registered subscriptions (componentMap) and returns them in a list.
     *
     * @param path - The base path, ex: "db.products"
     * @param newObj - The new object, ex: { "1": { name: "foo" } }
     * @returns Array of keys (paths) that have subscribers
     */
    CollabStateSingleton.prototype.getNotifies = function (path, newObj) {
        var _this = this;
        var ret = [];
        var visit = function (currentPath, value) {
            if (value && typeof value === "object") {
                Object.keys(value).forEach(function (k) {
                    var nextPath = /^\d+$/.test(k)
                        ? "".concat(currentPath, "[").concat(k, "]")
                        : "".concat(currentPath, ".").concat(k);
                    if (_this.componentMap.has(nextPath)) {
                        ret.push(nextPath);
                    }
                    visit(nextPath, value[k]);
                });
            }
        };
        visit(path, newObj);
        return ret;
    };
    /**
     * Logs the state change in history.
     * @param key - The state key that was changed.
     * @param value - The new state value.
     * @param system - Indicates whether the change was made by the system.
     */
    CollabStateSingleton.prototype.logHistory = function (key, value, system) {
        var entry = {
            timestamp: Date.now(),
            system: system,
            key: key,
            value: value
        };
        this.history.push(entry);
        // Keep only the last 10,000 entries
        if (this.history.length > 10000) {
            this.history.shift();
        }
    };
    /**
     * Retrieves the history of state changes.
     */
    CollabStateSingleton.prototype.getHistory = function () {
        return this.history;
    };
    /**
     * clear all entries in the history
     */
    CollabStateSingleton.prototype.clearHistory = function () {
        this.history = [];
    };
    CollabStateSingleton.prototype.subscribe = function (keyOrKeys, component, id) {
        var _this = this;
        var keys = Array.isArray(keyOrKeys) ? keyOrKeys : [keyOrKeys];
        keys.forEach(function (key) {
            if (!key.includes(';'))
                key = ";".concat(key);
            if (isTrace)
                console.log('subscribe key(s)', keyOrKeys);
            var isExclusive = key.startsWith('*');
            if (isExclusive) {
                _this.componentMap.delete(key); // clear olds subscribes
            }
            if (!_this.componentMap.has(key)) {
                _this.componentMap.set(key, new Set());
            }
            _this.componentMap.get(key).add(component);
        });
    };
    CollabStateSingleton.prototype.unsubscribe = function (keyOrKeys, component) {
        var _this = this;
        var keys = Array.isArray(keyOrKeys) ? keyOrKeys : [keyOrKeys];
        keys.forEach(function (key) {
            var _a, _b;
            if (!key.includes(';'))
                key = ";".concat(key);
            if (component === "*") {
                if (isTrace)
                    console.log('unsubscribe key', key, " all components");
                _this.componentMap.set(key, new Set());
            }
            else {
                if (isTrace)
                    console.log('unsubscribe key', key, (_a = _this.componentMap.get(key)) === null || _a === void 0 ? void 0 : _a.has(component));
                (_b = _this.componentMap.get(key)) === null || _b === void 0 ? void 0 : _b.delete(component);
            }
        });
    };
    CollabStateSingleton.prototype.notify = function (keys) {
        var _this = this;
        if (typeof keys === "string")
            keys = [keys];
        for (var _i = 0, keys_1 = keys; _i < keys_1.length; _i++) {
            var key = keys_1[_i];
            if (!this.notifyQueue.includes(key)) {
                this.notifyQueue.push(key);
            }
        }
        if (this.isNotifying)
            return;
        this.isNotifying = true;
        var nextKey = "";
        try {
            while (this.notifyQueue.length > 0) {
                nextKey = this.notifyQueue.shift();
                if (isTrace)
                    console.log("notify key=".concat(nextKey), this.componentMap);
                Array.from(this.componentMap).find(function (map) {
                    var stateKey = map[0], arr = map[1];
                    var path = stateKey.split(';')[1];
                    if (path !== nextKey)
                        return;
                    arr.forEach(function (component) {
                        if ('handleIcaStateChange' in component) {
                            component['handleIcaStateChange'](nextKey, _this.getState(nextKey));
                        }
                        else if (typeof component === 'function') {
                            component(nextKey, _this.getState(nextKey));
                        }
                        else {
                            console.error('invalid notify on key: ' + nextKey);
                        }
                    });
                });
            }
        }
        catch (e) {
            console.error("error on notify, key: " + nextKey, e);
        }
        finally {
            this.isNotifying = false;
        }
    };
    /**
     * Get statistics about current state keys and their subscribers.
     */
    CollabStateSingleton.prototype.getStateStatistics = function () {
        var statistics = new Map();
        this.componentMap.forEach(function (value, key) {
            statistics.set(key, value.size);
        });
        return statistics;
    };
    return CollabStateSingleton;
}());
function getCollabStateInstance() {
    var win = getCollabWindow();
    if (!win.collabState) {
        win.collabState = new CollabStateSingleton();
    }
    return win.collabState;
}
if (!exports.globalState.globalStateManagment)
    exports.globalState.globalStateManagment = getCollabStateInstance();
if (!exports.globalState._ica)
    exports.globalState._ica = {};
