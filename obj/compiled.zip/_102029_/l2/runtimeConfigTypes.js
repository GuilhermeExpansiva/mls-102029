/// <mls fileReference="_102029_/l2/runtimeConfigTypes.ts" enhancement="_blank" />
export const L4_CONTEXT_ORIGIN_CATALOG = {
    actorSession: ['actorSession.actorId', 'actorSession.scope'],
    currentWorkspace: ['currentWorkspace.workspaceId'],
    systemDefault: ['systemDefault.now', 'systemDefault.uuid', 'systemDefault.locale'],
};
