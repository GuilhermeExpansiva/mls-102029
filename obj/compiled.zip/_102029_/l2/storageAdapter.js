/// <mls fileReference="_102029_/l2/storageAdapter.ts" enhancement="_blank"/>
let _adapter = null;
export function setStorageAdapter(adapter) {
    _adapter = adapter;
}
function getAdapter() {
    if (!_adapter) {
        throw new Error('[storageAdapter] not initialized');
    }
    return _adapter;
}
export const storage = {
    getTask: (taskId) => getAdapter().getTask(taskId),
    getMessage: (messageId) => getAdapter().getMessage(messageId),
    addOrUpdateTask: (task) => getAdapter().addOrUpdateTask(task),
    addPooling: (pooling) => getAdapter().addPooling(pooling),
    deletePooling: (taskId) => getAdapter().deletePooling(taskId),
    updateThreadPendingTasks: (threadId, taskId) => getAdapter().updateThreadPendingTasks(threadId, taskId),
};
