"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getInteractionState = getInteractionState;
exports.subscribeToInteractionState = subscribeToInteractionState;
exports.clearBlockingError = clearBlockingError;
exports.normalizeInteractionError = normalizeInteractionError;
exports.retryBlockingError = retryBlockingError;
exports.beginExpectedNavigationLoad = beginExpectedNavigationLoad;
exports.consumeExpectedNavigationLoad = consumeExpectedNavigationLoad;
exports.bindExpectedNavigationLoad = bindExpectedNavigationLoad;
exports.runBlockingUiAction = runBlockingUiAction;
var DIMMED_DELAY_MS = 600;
var DEFAULT_TIMEOUT_MS = 10000;
function traceLazy(event, details) {
    if (!globalThis.window || !window.isTraceLazy) {
        return;
    }
    console.log('[traceLazy][interaction]', event, details !== null && details !== void 0 ? details : {});
}
var listeners = new Set();
var currentState = {
    busy: false,
    busyPhase: 'idle',
    clearContentWhileBusy: false,
};
var busyPromise = null;
var dimmedTimer = null;
var timeoutTimer = null;
var pendingNavigationLoad = null;
var activeRetry;
function createDeferred() {
    var resolve;
    var reject;
    var promise = new Promise(function (resolvePromise, rejectPromise) {
        resolve = resolvePromise;
        reject = rejectPromise;
    });
    return { promise: promise, resolve: resolve, reject: reject };
}
function emitState() {
    if (globalThis.window) {
        window.collabAuraInteractionState = currentState;
    }
    listeners.forEach(function (listener) { return listener(currentState); });
}
function setState(nextState) {
    currentState = nextState;
    emitState();
}
function clearTimers() {
    if (dimmedTimer !== null) {
        globalThis.clearTimeout(dimmedTimer);
        dimmedTimer = null;
    }
    if (timeoutTimer !== null) {
        globalThis.clearTimeout(timeoutTimer);
        timeoutTimer = null;
    }
}
function publishBlockingError(error, options) {
    var _a;
    var blockingError = {
        title: (_a = options.errorTitle) !== null && _a !== void 0 ? _a : 'Nao foi possivel carregar esta pagina',
        error: error,
        canRetry: typeof options.retry === 'function',
    };
    setState({
        busy: false,
        busyPhase: 'idle',
        busyLabel: undefined,
        clearContentWhileBusy: false,
        blockingError: blockingError,
    });
}
function getInteractionState() {
    return currentState;
}
function subscribeToInteractionState(listener) {
    listeners.add(listener);
    listener(currentState);
    return function () {
        listeners.delete(listener);
    };
}
function clearBlockingError() {
    if (!currentState.blockingError) {
        return;
    }
    setState(__assign(__assign({}, currentState), { blockingError: undefined }));
}
function normalizeInteractionError(error) {
    if (error && typeof error === 'object' && 'code' in error && 'message' in error) {
        var candidate = error;
        if (typeof candidate.code === 'string' && typeof candidate.message === 'string') {
            return {
                code: candidate.code,
                message: candidate.message,
                details: candidate.details,
            };
        }
    }
    if (error instanceof Error) {
        return {
            code: 'UNEXPECTED_ERROR',
            message: error.message,
        };
    }
    return {
        code: 'UNEXPECTED_ERROR',
        message: String(error),
    };
}
function retryBlockingError() {
    return __awaiter(this, void 0, void 0, function () {
        var retry;
        var _a;
        return __generator(this, function (_b) {
            switch (_b.label) {
                case 0:
                    retry = (((_a = currentState.blockingError) === null || _a === void 0 ? void 0 : _a.canRetry) ? activeRetry : undefined);
                    if (!retry) {
                        return [2 /*return*/];
                    }
                    clearBlockingError();
                    return [4 /*yield*/, retry()];
                case 1:
                    _b.sent();
                    return [2 /*return*/];
            }
        });
    });
}
function beginExpectedNavigationLoad(signal) {
    var deferred = createDeferred();
    pendingNavigationLoad = {
        consumed: false,
        promise: deferred.promise,
        resolve: deferred.resolve,
        reject: deferred.reject,
        signal: signal,
    };
    traceLazy('beginExpectedNavigationLoad', {
        hasSignal: Boolean(signal),
    });
    return deferred.promise;
}
function consumeExpectedNavigationLoad() {
    if (!pendingNavigationLoad || pendingNavigationLoad.consumed) {
        traceLazy('consumeExpectedNavigationLoad.miss');
        return null;
    }
    pendingNavigationLoad.consumed = true;
    traceLazy('consumeExpectedNavigationLoad.hit', {
        hasSignal: Boolean(pendingNavigationLoad.signal),
    });
    return pendingNavigationLoad;
}
function bindExpectedNavigationLoad(pending, promise) {
    if (!pending) {
        return;
    }
    traceLazy('bindExpectedNavigationLoad', {
        hasSignal: Boolean(pending.signal),
    });
    promise.then(function () { return pending.resolve(); }, function (error) { return pending.reject(error); }).finally(function () {
        if (pendingNavigationLoad === pending) {
            pendingNavigationLoad = null;
        }
    });
}
function runBlockingUiAction(action_1) {
    return __awaiter(this, arguments, void 0, function (action, options) {
        var mode, controller_1, controller, timeoutMs;
        var _a, _b, _c, _d, _e;
        if (options === void 0) { options = {}; }
        return __generator(this, function (_f) {
            mode = (_a = options.mode) !== null && _a !== void 0 ? _a : 'blocking';
            if (mode === 'silent') {
                controller_1 = new AbortController();
                traceLazy('runBlockingUiAction.silent');
                return [2 /*return*/, action(controller_1.signal)];
            }
            if (busyPromise) {
                traceLazy('runBlockingUiAction.reuseBusyPromise');
                return [2 /*return*/, busyPromise];
            }
            clearBlockingError();
            controller = new AbortController();
            timeoutMs = (_b = options.timeoutMs) !== null && _b !== void 0 ? _b : DEFAULT_TIMEOUT_MS;
            setState({
                busy: true,
                busyPhase: 'subtle',
                busyLabel: (_c = options.busyLabel) !== null && _c !== void 0 ? _c : 'Processando...',
                clearContentWhileBusy: (_d = options.clearContentWhileBusy) !== null && _d !== void 0 ? _d : false,
                blockingError: undefined,
            });
            traceLazy('runBlockingUiAction.start', {
                clearContentWhileBusy: (_e = options.clearContentWhileBusy) !== null && _e !== void 0 ? _e : false,
                timeoutMs: timeoutMs,
            });
            dimmedTimer = globalThis.setTimeout(function () {
                traceLazy('runBlockingUiAction.dimmed');
                setState(__assign(__assign({}, currentState), { busy: true, busyPhase: 'dimmed' }));
            }, DIMMED_DELAY_MS);
            busyPromise = new Promise(function (resolve, reject) {
                timeoutTimer = globalThis.setTimeout(function () {
                    traceLazy('runBlockingUiAction.timeout');
                    controller.abort(new Error('TIMEOUT'));
                }, timeoutMs);
                var aborted = new Promise(function (_, rejectAbort) {
                    controller.signal.addEventListener('abort', function () {
                        var _a;
                        rejectAbort((_a = controller.signal.reason) !== null && _a !== void 0 ? _a : new Error('TIMEOUT'));
                    }, { once: true });
                });
                Promise.race([
                    Promise.resolve().then(function () { return action(controller.signal); }),
                    aborted,
                ])
                    .then(function (result) {
                    clearTimers();
                    busyPromise = null;
                    activeRetry = undefined;
                    traceLazy('runBlockingUiAction.success');
                    setState({
                        busy: false,
                        busyPhase: 'idle',
                        busyLabel: undefined,
                        clearContentWhileBusy: false,
                        blockingError: undefined,
                    });
                    resolve(result);
                })
                    .catch(function (error) {
                    clearTimers();
                    busyPromise = null;
                    activeRetry = options.retry;
                    var normalized = controller.signal.aborted
                        ? {
                            code: 'TIMEOUT',
                            message: 'O servidor demorou demais para responder.',
                        }
                        : normalizeInteractionError(error);
                    traceLazy('runBlockingUiAction.error', {
                        code: normalized.code,
                        message: normalized.message,
                    });
                    publishBlockingError(normalized, options);
                    reject(normalized);
                });
            });
            return [2 /*return*/, busyPromise];
        });
    });
}
