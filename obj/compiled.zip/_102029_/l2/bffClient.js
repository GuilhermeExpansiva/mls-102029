import { telemetryQueue } from '/_102029_/l2/telemetry.js';
function traceLazy(event, details) {
    if (!globalThis.window || !window.isTraceLazy) {
        return;
    }
    console.log('[traceLazy][bff-client]', event, details ?? {});
}
let _userId = 'anonymous';
export function setUserId(id) {
    _userId = id;
    telemetryQueue.setUserId(id);
}
export function pushTelemetry(event) {
    telemetryQueue.push(event);
}
const DEFAULT_TIMEOUT_MS = 10000;
export async function execBff(routine, params, options = {}) {
    const controller = new AbortController();
    const cleanupTimeout = globalThis.setTimeout(() => {
        controller.abort(new Error('TIMEOUT'));
    }, options.timeoutMs ?? DEFAULT_TIMEOUT_MS);
    const signal = options.signal
        ? AbortSignal.any([controller.signal, options.signal])
        : controller.signal;
    try {
        traceLazy('request.start', {
            routine,
            timeoutMs: options.timeoutMs ?? DEFAULT_TIMEOUT_MS,
            mode: options.mode ?? 'silent',
        });
        const response = await fetch('/execBff', {
            method: 'POST',
            headers: {
                'content-type': 'application/json',
            },
            body: JSON.stringify({
                routine,
                params,
                meta: {
                    source: 'http',
                    userId: _userId,
                    telemetry: telemetryQueue.flush(),
                },
            }),
            signal,
        });
        traceLazy('request.response', {
            routine,
        });
        return response.json();
    }
    catch (error) {
        if (signal.aborted) {
            traceLazy('request.timeout', {
                routine,
            });
            return {
                ok: false,
                data: null,
                error: {
                    code: 'TIMEOUT',
                    message: 'O servidor demorou demais para responder.',
                },
            };
        }
        traceLazy('request.networkError', {
            routine,
            message: error instanceof Error ? error.message : String(error),
        });
        return {
            ok: false,
            data: null,
            error: {
                code: 'NETWORK_ERROR',
                message: 'Servidor indisponivel ou sem conexao.',
                details: error instanceof Error ? error.message : String(error),
            },
        };
    }
    finally {
        globalThis.clearTimeout(cleanupTimeout);
    }
}
