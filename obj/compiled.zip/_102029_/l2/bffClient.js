import { telemetryQueue } from '/_102029_/l2/telemetry.js';
function traceLazy(event, details) {
    if (!globalThis.window || !window.isTraceLazy) {
        return;
    }
    console.log('[traceLazy][bff-client]', event, details ?? {});
}
let _userId = 'anonymous';
let importedTransportUrl = null;
let importedTransport = null;
export function setUserId(id) {
    _userId = id;
    telemetryQueue.setUserId(id);
}
export function pushTelemetry(event) {
    telemetryQueue.push(event);
}
const DEFAULT_TIMEOUT_MS = 10000;
function getBffHost() {
    return globalThis;
}
function getRegisteredTransport() {
    const host = getBffHost();
    return host.window?.collabBffTransport ?? host.collabBffTransport ?? null;
}
function getTransportModuleUrl() {
    const host = getBffHost();
    return host.window?.collabBffTransportModule ?? host.collabBffTransportModule ?? null;
}
function normalizeTransportModule(mod) {
    const record = mod;
    const exported = record.default ?? record;
    if (typeof exported === 'function') {
        return {
            execBff: exported,
        };
    }
    if (exported && typeof exported === 'object' && typeof exported.execBff === 'function') {
        return exported;
    }
    if (typeof record.execBff === 'function') {
        return {
            execBff: record.execBff,
        };
    }
    throw new Error('BFF transport module must export execBff or a default transport');
}
async function resolveDirectTransport() {
    const registered = getRegisteredTransport();
    if (registered) {
        return registered;
    }
    const moduleUrl = getTransportModuleUrl();
    if (!moduleUrl) {
        return null;
    }
    if (!importedTransport || importedTransportUrl !== moduleUrl) {
        importedTransportUrl = moduleUrl;
        importedTransport = import(moduleUrl)
            .then(normalizeTransportModule)
            .catch((error) => {
            if (importedTransportUrl === moduleUrl) {
                importedTransportUrl = null;
                importedTransport = null;
            }
            throw error;
        });
    }
    return importedTransport;
}
function createRequest(routine, params, source) {
    return {
        routine,
        params,
        meta: {
            source,
            userId: _userId,
            telemetry: telemetryQueue.flush(),
        },
    };
}
function unwrapDirectResult(result) {
    if (result && typeof result === 'object' && 'response' in result) {
        return result.response;
    }
    return result;
}
function withAbort(operation, signal) {
    if (signal.aborted) {
        return Promise.reject(signal.reason ?? new Error('aborted'));
    }
    return new Promise((resolve, reject) => {
        const handleAbort = () => {
            reject(signal.reason ?? new Error('aborted'));
        };
        signal.addEventListener('abort', handleAbort, { once: true });
        operation
            .then(resolve, reject)
            .finally(() => {
            signal.removeEventListener('abort', handleAbort);
        });
    });
}
export async function execBff(routine, params, options = {}) {
    const controller = new AbortController();
    const cleanupTimeout = globalThis.setTimeout(() => {
        controller.abort(new Error('TIMEOUT'));
    }, options.timeoutMs ?? DEFAULT_TIMEOUT_MS);
    const signal = options.signal
        ? AbortSignal.any([controller.signal, options.signal])
        : controller.signal;
    try {
        traceLazy('request.start', {
            routine,
            timeoutMs: options.timeoutMs ?? DEFAULT_TIMEOUT_MS,
            mode: options.mode ?? 'silent',
        });
        const directTransport = await withAbort(resolveDirectTransport(), signal);
        if (directTransport) {
            traceLazy('request.direct.start', {
                routine,
            });
            const result = await withAbort(directTransport.execBff(createRequest(routine, params, 'test'), {
                ...options,
                signal,
            }), signal);
            traceLazy('request.direct.response', {
                routine,
            });
            return unwrapDirectResult(result);
        }
        const response = await fetch('/execBff', {
            method: 'POST',
            headers: {
                'content-type': 'application/json',
            },
            body: JSON.stringify(createRequest(routine, params, 'http')),
            signal,
        });
        traceLazy('request.response', {
            routine,
        });
        return response.json();
    }
    catch (error) {
        if (signal.aborted) {
            traceLazy('request.timeout', {
                routine,
            });
            return {
                ok: false,
                data: null,
                error: {
                    code: 'TIMEOUT',
                    message: 'O servidor demorou demais para responder.',
                },
            };
        }
        traceLazy('request.networkError', {
            routine,
            message: error instanceof Error ? error.message : String(error),
        });
        return {
            ok: false,
            data: null,
            error: {
                code: 'NETWORK_ERROR',
                message: 'Servidor indisponivel ou sem conexao.',
                details: error instanceof Error ? error.message : String(error),
            },
        };
    }
    finally {
        globalThis.clearTimeout(cleanupTimeout);
    }
}
