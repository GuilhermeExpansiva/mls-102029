"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.execBff = execBff;
function traceLazy(event, details) {
    if (!globalThis.window || !window.isTraceLazy) {
        return;
    }
    console.log('[traceLazy][bff-client]', event, details !== null && details !== void 0 ? details : {});
}
var DEFAULT_TIMEOUT_MS = 10000;
function execBff(routine_1, params_1) {
    return __awaiter(this, arguments, void 0, function (routine, params, options) {
        var controller, cleanupTimeout, signal, response, error_1;
        var _a, _b, _c;
        if (options === void 0) { options = {}; }
        return __generator(this, function (_d) {
            switch (_d.label) {
                case 0:
                    controller = new AbortController();
                    cleanupTimeout = globalThis.setTimeout(function () {
                        controller.abort(new Error('TIMEOUT'));
                    }, (_a = options.timeoutMs) !== null && _a !== void 0 ? _a : DEFAULT_TIMEOUT_MS);
                    signal = options.signal
                        ? AbortSignal.any([controller.signal, options.signal])
                        : controller.signal;
                    _d.label = 1;
                case 1:
                    _d.trys.push([1, 3, 4, 5]);
                    traceLazy('request.start', {
                        routine: routine,
                        timeoutMs: (_b = options.timeoutMs) !== null && _b !== void 0 ? _b : DEFAULT_TIMEOUT_MS,
                        mode: (_c = options.mode) !== null && _c !== void 0 ? _c : 'silent',
                    });
                    return [4 /*yield*/, fetch('/execBff', {
                            method: 'POST',
                            headers: {
                                'content-type': 'application/json',
                            },
                            body: JSON.stringify({
                                routine: routine,
                                params: params,
                                meta: {
                                    source: 'http',
                                },
                            }),
                            signal: signal,
                        })];
                case 2:
                    response = _d.sent();
                    traceLazy('request.response', {
                        routine: routine,
                    });
                    return [2 /*return*/, response.json()];
                case 3:
                    error_1 = _d.sent();
                    if (signal.aborted) {
                        traceLazy('request.timeout', {
                            routine: routine,
                        });
                        return [2 /*return*/, {
                                ok: false,
                                data: null,
                                error: {
                                    code: 'TIMEOUT',
                                    message: 'O servidor demorou demais para responder.',
                                },
                            }];
                    }
                    traceLazy('request.networkError', {
                        routine: routine,
                        message: error_1 instanceof Error ? error_1.message : String(error_1),
                    });
                    return [2 /*return*/, {
                            ok: false,
                            data: null,
                            error: {
                                code: 'NETWORK_ERROR',
                                message: 'Servidor indisponivel ou sem conexao.',
                                details: error_1 instanceof Error ? error_1.message : String(error_1),
                            },
                        }];
                case 4:
                    globalThis.clearTimeout(cleanupTimeout);
                    return [7 /*endfinally*/];
                case 5: return [2 /*return*/];
            }
        });
    });
}
