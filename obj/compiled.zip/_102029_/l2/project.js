"use strict";
/// <mls fileReference="_102029_/l2/project.ts" enhancement="_blank" />
Object.defineProperty(exports, "__esModule", { value: true });
exports.projectConfig = void 0;
exports.projectConfig = {
    masterFrontEnd: {
        build: '',
        start: '',
        liveView: '',
    },
    masterBackEnd: {
        build: '',
        start: '',
        serverView: ''
    },
    modules: []
};
