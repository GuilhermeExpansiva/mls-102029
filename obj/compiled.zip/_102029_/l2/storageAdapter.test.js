/// <mls fileReference="_102029_/l2/storageAdapter.test.ts" enhancement="_blank"/>
export const integrations = [];
export const tests = [];
