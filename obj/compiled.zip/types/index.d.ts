declare module "_102029_/l2/contracts/bootstrap" {
    export type AuraShellMode = 'spa' | 'pwa';
    export type AuraDeviceKind = 'desktop' | 'mobile';
    export type AuraAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export type AuraGenomeLayout = 'standart' | 'tabs' | 'compact' | 'aside' | 'bento-grids';
    export type AuraDesignSystem = 'default' | string;
    export interface IPaths {
        webSharedPath: string;
        webSharedSkill: string;
    }
    export interface IGenomeConfig {
        device: AuraDeviceKind;
        designSystem: AuraDesignSystem;
        designSystemSkill: string;
        layout: AuraGenomeLayout;
        layoutSkill: string;
    }
    export interface AuraRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export interface AuraLayoutConfig {
        regions: {
            desktop: AuraRegionVisibility;
            mobile: AuraRegionVisibility;
        };
        asideMode: {
            desktop: AuraAsideMode;
            mobile: AuraAsideMode;
        };
    }
    export interface AuraRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export type AuraRouteMatchMode = 'exact' | 'prefix';
    export interface AuraRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: AuraRouteMatchMode;
    }
    export interface AuraModuleFrontendDefinition {
        pageTitle?: string;
        device?: AuraDeviceKind;
        navigation?: AuraNavigationItem[];
        routes: AuraRouteDefinition[];
        headerRenderer?: AuraRegionRendererConfig;
        asideRenderer?: AuraRegionRendererConfig;
    }
    export interface AuraNavigationItem {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface AuraModuleShellPreferences {
        layout?: Partial<AuraLayoutConfig>;
    }
    export interface AuraBootConfig {
        projectId: string;
        moduleId: string;
        basePath: string;
        shellMode: AuraShellMode;
        device: AuraDeviceKind;
        routes: AuraRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: AuraNavigationItem[];
        moduleLinks?: AuraNavigationItem[];
        layout: AuraLayoutConfig;
    }
    export type AuraInteractionMode = 'blocking' | 'silent';
    export type AuraBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface AuraNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface AuraBlockingErrorState {
        title: string;
        error: AuraNormalizedError;
        canRetry: boolean;
    }
    export interface AuraInteractionState {
        busy: boolean;
        busyPhase: AuraBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: AuraBlockingErrorState;
    }
    global {
        interface Window {
            collabAuraShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
            };
        }
        interface Window {
            collabBoot?: AuraBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabAuraInteractionState?: AuraInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
declare module "_102029_/l2/telemetry" {
    export interface ClientTelemetryEvent {
        eventType: string;
        label: string;
        durationMs?: number | null;
        metadata?: Record<string, unknown> | null;
        recordedAt: string;
    }
    class TelemetryQueue {
        private queue;
        private userId;
        constructor();
        setUserId(id: string): void;
        push(event: ClientTelemetryEvent): void;
        flush(): ClientTelemetryEvent[];
        measureAsync<T>(label: string, fn: () => Promise<T>): Promise<T>;
        private sendBeacon;
    }
    export const telemetryQueue: TelemetryQueue;
}
declare module "_102029_/l2/bffClient" {
    import type { AuraInteractionMode, AuraNormalizedError } from "_102029_/l2/contracts/bootstrap";
    import { type ClientTelemetryEvent } from "_102029_/l2/telemetry";
    export type { ClientTelemetryEvent };
    export interface BffClientOptions {
        mode?: AuraInteractionMode;
        timeoutMs?: number;
        signal?: AbortSignal;
    }
    export interface BffClientResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: AuraNormalizedError | null;
        telemetryReceived?: number;
    }
    export function setUserId(id: string): void;
    export function pushTelemetry(event: ClientTelemetryEvent): void;
    export function execBff<TData = unknown>(routine: string, params: unknown, options?: BffClientOptions): Promise<BffClientResponse<TData>>;
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/collabDecorators" {
    import { PropertyDeclaration } from 'lit';
    /**
     * Custom decorator to bind properties to multiple data sources dynamically.
     * @param options - Property options, including type and default value.
     * Accepts variations, e.g., label="Hello {{user.name}}" label-pt="Olá {{user.name}}".
     * Do not use this for changing data sources dynamically (e.g., input values);
     * use `propertyDataSource` instead.
     * This decorator will read state values but does not persist changes to the state.
     */
    export function propertyCompositeDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    /**
     * Custom decorator to bind properties either to static data or dynamically from CollabState.
     * @param options - Property options, including type and default value.
     * Does not support variations; use `propertyCompositeDataSource` for variations.
     * For example, label="Hello {{user.name}}" label-pt="Olá {{user.name}}" (label-pt is ignored).
     * This decorator will read state values and persist changes to the state.
     */
    export function propertyDataSource(options?: PropertyDeclaration): (proto: any, propName: PropertyKey) => any;
    export interface OptionItem {
        key: string;
        value: string;
    }
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102029_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102029_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102029_/l2/interactionRuntime" {
    import type { AuraInteractionMode, AuraInteractionState, AuraNormalizedError } from "_102029_/l2/contracts/bootstrap";
    type InteractionListener = (state: AuraInteractionState) => void;
    interface BlockingActionOptions {
        mode?: AuraInteractionMode;
        timeoutMs?: number;
        clearContentWhileBusy?: boolean;
        busyLabel?: string;
        retry?: () => Promise<unknown> | unknown;
        errorTitle?: string;
    }
    interface PendingNavigationLoad {
        consumed: boolean;
        promise: Promise<void>;
        resolve: () => void;
        reject: (error: unknown) => void;
        signal?: AbortSignal;
    }
    export function getInteractionState(): AuraInteractionState;
    export function subscribeToInteractionState(listener: InteractionListener): () => void;
    export function clearBlockingError(): void;
    export function normalizeInteractionError(error: unknown): AuraNormalizedError;
    export function retryBlockingError(): Promise<void>;
    export function beginExpectedNavigationLoad(signal?: AbortSignal): Promise<void>;
    export function consumeExpectedNavigationLoad(): PendingNavigationLoad;
    export function bindExpectedNavigationLoad(pending: PendingNavigationLoad | null, promise: Promise<unknown>): void;
    export function runBlockingUiAction<T>(action: (signal: AbortSignal) => Promise<T>, options?: BlockingActionOptions): Promise<T | undefined>;
}
declare module "_102029_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102029_/l2/shellEvents" {
    export const AURA_TOGGLE_ASIDE_EVENT = "collab-aura:toggle-aside";
    export const AURA_OPEN_ASIDE_EVENT = "collab-aura:open-aside";
    export const AURA_CLOSE_ASIDE_EVENT = "collab-aura:close-aside";
    export function toggleAuraAside(): void;
    export function openAuraAside(): void;
    export function closeAuraAside(): void;
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from "_102029_/l2/collabLitElement";
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102029_/l2/webCrypto" {
    export function createRuntimeUuid(): string;
    export function fillRandomBytes(bytes: Uint8Array): Uint8Array;
    export function sha256Hex(input: string): Promise<string>;
}
declare module "_102029_/l2/uuidv7" {
    export function createUuidV7(): string;
}
