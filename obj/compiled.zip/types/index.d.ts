declare module "_102029_/l2/aiAgentBase.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102029_/l2/aiAgentBase" {
    import { TemplateResult } from 'lit';
    /**
     * Agent Architecture Overview
     *
     * The platform supports two agent models. The developer must choose
     * **one model per agent**, based on responsibility and complexity.
     *
     * 1) IAgent (procedural model)
     *    - The agent participates in the execution lifecycle.
     *    - It may orchestrate steps, call tools, and trigger side effects.
     *    - Responsibility: **who executes**.
     *    - Use this when flexibility and custom flow control are required.
     *
     * 2) IAgentAsync (declarative model)
     *    - The agent only describes what should be done and returns data
     *      (e.g. system and human prompts).
     *    - It does NOT execute side effects or control the flow.
     *    - Responsibility: **who describes what must be done**.
     *    - The core is responsible for execution, retries, policies, and limits.
     *    - This model naturally enables **parallel execution**, since agents
     *      are stateless and independent.
     *    - Multiple steps may run concurrently without increasing agent complexity.
     *    - Use this model when simplicity, predictability, testability,
     *      and parallelism are important.
     *
     * Both models coexist without breaking changes.
     * Choose the simplest model that satisfies your use case.
     */
    export type IAgent = IAgentMeta & IAgentLifecycle & IAgentLifecycleSync;
    export type IAgentAsync = IAgentMeta & IAgentLifecycle & IAgentLifecycleHooks;
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export type IAgentLifecycle = {
        beforeClarification?(context: mls.msg.ExecutionContext, stepId: number, readOnly: boolean): Promise<HTMLDivElement | null>;
        afterClarification?(context: mls.msg.ExecutionContext, stepId: number, data: object): Promise<void>;
        afterTool?(context: mls.msg.ExecutionContext, stepId: number): Promise<void>;
        installBot?(context: mls.msg.ExecutionContext): Promise<boolean>;
        beforeBot?(context: mls.msg.ExecutionContext, msg: string, toolsBeforeSendMessage: mls.bots.ToolsBeforeSendMessage[]): Promise<Record<string, any>>;
        afterBot?(context: mls.msg.ExecutionContext, output: mls.msg.BotOutput): Promise<string>;
        replayForSupport?(task: mls.msg.ExecutionContext, payload: mls.msg.AIPayload[]): Promise<void>;
        getFeedBack?(task: mls.msg.TaskData): Promise<TemplateResult>;
    };
    export type IAgentLifecycleSync = {
        beforePrompt(context: mls.msg.ExecutionContext): Promise<void>;
        afterPrompt(context: mls.msg.ExecutionContext): Promise<void>;
    };
    /**
     * Declarative agent lifecycle hooks.
     *
     * These hooks describe what should happen at each entry point
     * without executing side effects (no tool calls, no I/O, no UI).
     *
     * The core orchestrator is responsible for executing the returned intents.
     * Async agents must implement at least one of these entry points.
     */
    export type IAgentLifecycleHooks = {
        /**
         * Called when the agent is invoked with an explicit user prompt
         * in the context of a file (editor, UI, etc).
         *
         * This starts a new task and returns declarative intents
         * describing the next steps to execute.
         */
        beforePromptAtomic?(agent: IAgentMeta, context: mls.msg.ExecutionContext, file: mls.stor.IFileInfo, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is invoked without a free-form user prompt.
         *
         * The user may optionally provide a command or parameters as part of the
         * agent invocation (e.g. "@@agentFix", "@@agentFix security").
         *
         * In this mode, the agent does not receive an explicit descriptive prompt.
         * Instead, the system infers the initial intent based on:
         * - the agent name
         * - optional command or parameters
         * - the current execution context
         *
         * This hook is responsible for creating a new task and returning the
         * initial orchestration intents.
         */
        beforePromptImplicit?(agent: IAgentMeta, context: mls.msg.ExecutionContext, userPrompt: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called when the agent is executed as part of an existing task,
         * following a previous step.
         *
         * The agent should read the current task state from the context
         * and return intents describing how the task should continue.
         *
         * Example:
         *   step1 -> agentFix
         *   step2 -> agentFix2 (reads data produced by agentFix)
         */
        beforePromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number, args?: string): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step has completed, allowing the agent to
         * react declaratively to the step result and append new intents.
         */
        afterPromptStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIAgentStep, hookSequential: number): Promise<mls.msg.AgentIntent[]>;
        /**
         * Called after a step user call to answer clarification allowing the agent to
         * react declaratively to the clarification result and append new intents.
         */
        beforeClarificationStep?(agent: IAgentMeta, context: mls.msg.ExecutionContext, parentStep: mls.msg.AIAgentStep, step: mls.msg.AIClarificationStep, hookSequential: number, json: any): Promise<HTMLElement>;
    };
    export interface ITool {
        toolName: string;
        tool_url: string | undefined;
        description: string;
        argsSchema: Record<string, any>;
        execute(args: Record<string, any>): Promise<any>;
    }
    export const svg_tool = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 512 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M176 88l0 40 160 0 0-40c0-4.4-3.6-8-8-8L184 80c-4.4 0-8 3.6-8 8zm-48 40l0-40c0-30.9 25.1-56 56-56l144 0c30.9 0 56 25.1 56 56l0 40 28.1 0c12.7 0 24.9 5.1 33.9 14.1l51.9 51.9c9 9 14.1 21.2 14.1 33.9l0 92.1-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32-128 0 0-32c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 32L0 320l0-92.1c0-12.7 5.1-24.9 14.1-33.9l51.9-51.9c9-9 21.2-14.1 33.9-14.1l28.1 0zM0 416l0-64 128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0c0 17.7 14.3 32 32 32s32-14.3 32-32l128 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64z\"/></svg>";
    export const svg_agent = "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 640 512\"><!--!Font Awesome Free 6.7.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license/free Copyright 2025 Fonticons, Inc.--><path d=\"M320 0c17.7 0 32 14.3 32 32l0 64 120 0c39.8 0 72 32.2 72 72l0 272c0 39.8-32.2 72-72 72l-304 0c-39.8 0-72-32.2-72-72l0-272c0-39.8 32.2-72 72-72l120 0 0-64c0-17.7 14.3-32 32-32zM208 384c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zm96 0c-8.8 0-16 7.2-16 16s7.2 16 16 16l32 0c8.8 0 16-7.2 16-16s-7.2-16-16-16l-32 0zM264 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm152 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM48 224l16 0 0 192-16 0c-26.5 0-48-21.5-48-48l0-96c0-26.5 21.5-48 48-48zm544 0c26.5 0 48 21.5 48 48l0 96c0 26.5-21.5 48-48 48l-16 0 0-192 16 0z\"/></svg>";
    /**
     * Agent middleware is a function that receives an IAgent and returns
     * a new IAgent that wraps the original one.
     *
     * Middleware must NOT change the agent contract or business semantics.
     * It should only handle cross-cutting concerns such as logging,
     * metrics, tracing, retries, or safety checks.
     *
     * Middleware should be stateless and rely on the execution context
     * for any per-run data, ensuring it works with singleton or factory-based agents.
     *
     * Usage pattern:
     *   const agent = withLogging(createAgent())
     */
    /**
     * Example
     * Adds logging around agent execution lifecycle.
     *
     * This middleware logs when the agent starts and finishes processing
     * a prompt without requiring any changes to the agent implementation.
     *
     * It wraps existing hooks safely and preserves optional capabilities.
     */
    export function withLogging(agent: IAgent): IAgent;
}
declare module "_102029_/l2/aiAgentDefaultFeedback.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102029_/l2/aiAgentDefaultFeedback" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    export class AiAgentDefaultFeedback102029 extends StateLitElement {
        task?: mls.msg.TaskData;
        message?: mls.msg.Message;
        selectedStep: mls.msg.AIPayload | null;
        selectedTraceStep: mls.msg.AIPayload | null;
        isAgentParallelMode: boolean;
        firstUpdated(): Promise<void>;
        updated(_changedProperties: Map<PropertyKey, unknown>): void;
        private getTitle;
        private getIconStep;
        private getIconTask;
        private getChildren;
        private renderStep;
        private renderTaskRootDetails;
        private renderActions;
        private pauseOrContinueTask;
        private restartPoolingTask;
        private renderTaskProgress;
        private renderTree;
        private renderDetails;
        private renderTrace;
        private renderLogItem;
        private tryParseJSON;
        render(): any;
        private iconError;
        private iconPending;
        private iconTaskPaused;
        private iconOk;
        private iconWaitingHumam;
        private iconWaitingAfter;
        private collab_bell;
        private collab_play;
        private collab_pause;
    }
}
declare module "_102029_/l2/aiAgentHelper.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102029_/l2/aiAgentHelper" {
    /**
     * Helper function to collect all steps from a task in a flat array
     */
    export const getAllSteps: (firstStep: mls.msg.AIPayload[] | undefined) => mls.msg.AIPayload[];
    export const getAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload | null;
    export const getAllAgentStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIPayload[] | null;
    export const getAgentsStepByAgentName: (task: mls.msg.TaskData, agentName: string, status?: mls.msg.AIStepStatus) => mls.msg.AIPayload[];
    export const getStepById: (task: mls.msg.TaskData, stepId: number) => mls.msg.AIPayload | null;
    export const getNextPendentStep: (task: mls.msg.TaskData) => mls.msg.AIPayload | null;
    export const getNextResultStep: (task: mls.msg.TaskData) => mls.msg.AIResultStep | null;
    export const getNextClarificationStep: (task: mls.msg.TaskData) => mls.msg.AIClarificationStep | null;
    export const getNextPendingStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getNextFlexiblePendingStep: (task: mls.msg.TaskData) => mls.msg.AIFlexibleResultStep | null;
    export const getNextInProgressStepByAgentName: (task: mls.msg.TaskData, agentName: string) => mls.msg.AIAgentStep | null;
    export const getRootAgent: (task: mls.msg.TaskData) => mls.msg.AIAgentStep | null;
    export const getInteractionStepId: (task: mls.msg.TaskData, stepId: number) => number | null;
    export type StatisticsAITask = {
        agents: number;
        tools: number;
        clarification: number;
        result: number;
        flexible: number;
        totalCost: number;
        totalSteps: number;
    };
    export const calculateStepsStatistics: (steps: mls.msg.AIPayload[], removeFirstStep: boolean) => StatisticsAITask;
    export const calculateStepsByFilter: (task: mls.msg.TaskData, filter: Record<string, any>) => number;
    export const getTemporaryContext: (threadId: string, userId: string, prompt: string) => mls.msg.ExecutionContext;
    export function notifyMessageSendChange(context: mls.msg.ExecutionContext): void;
    export function notifyTaskChange(context: mls.msg.ExecutionContext, oldContextCreateAt?: string): void;
    export function notifyTaskCompleted(context: mls.msg.ExecutionContext, result?: string): void;
    export function notifyThreadChange(thread: mls.msg.Thread): void;
    export function notifyMessageChange(message: mls.msg.Message): void;
    export function notifyThreadCreate(thread: mls.msg.Thread): void;
    export function dispatchDetailsTaskClose(taskId: string): void;
    export function getTotalCost(task: mls.msg.TaskData): string;
    export function getNextStepIdAvaliable(task: mls.msg.TaskData): number;
}
declare module "_102029_/l2/aiAgentOrchestration.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102029_/l2/aiAgentOrchestration" {
    import { IAgent, IAgentAsync } from '_102029_/l2/aiAgentBase';
    export function executeBeforePrompt(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext): Promise<void>;
    export function continuePoolingTask(context: mls.msg.ExecutionContext): Promise<void>;
    export function pauseOrContinueTask(reason: string, context: mls.msg.ExecutionContext, action: "paused" | "continue"): Promise<void>;
    export function executeTool(toolName: string, args: string): Promise<IExecuteToolReturn>;
    export function finishClarification(agent: IAgent | IAgentAsync, stepId: number, parentStepId: number, intents: mls.msg.AgentIntent[], context: mls.msg.ExecutionContext, value: string, action: "continue" | "cancel"): Promise<void>;
    export function prepareClarificationElement(agent: IAgent | IAgentAsync, context: mls.msg.ExecutionContext, stepId: number, parentStepId: number, intents: mls.msg.AgentIntent[], clarification: ClarificationValue | Object | string): Promise<HTMLElement>;
    export function getClarificationElement(context: mls.msg.ExecutionContext): Promise<HTMLElement>;
    export function getAgentContext(taskId: string): Promise<{
        context: mls.msg.ExecutionContext;
        interaction: mls.msg.AIAgentStep;
        step: mls.msg.AIPayload;
    }>;
    export function loadAgent(agentName: string): Promise<IAgent | IAgentAsync | undefined>;
    export function loadTool(toolName: string): Promise<any | undefined>;
    type InstanceMode = 'agent' | 'tool';
    /**
     * agentName, ex: 'agentXX1' or '_100554_/l2/agents/agentXX1'
     */
    export function getInstanceByName(nameOrPath: string, mode: InstanceMode): Promise<IAgent | IAgentAsync | undefined>;
    export interface IExecuteToolReturn {
        status: boolean;
        error: string;
        result: any;
    }
    export interface ClarificationValue {
        taskId: string;
        stepId: number;
        title: string;
        userLanguage: string;
        questions: ClarificationQuestions;
        legends: string[];
    }
    export interface ClarificationQuestions {
        [key: string]: Question;
    }
    export interface Question {
        type: 'open' | 'select' | 'boolean' | 'MoSCoW' | 'range';
        question: string;
        answer?: string | boolean;
        options?: QuestionOption[];
    }
    export interface QuestionOption {
        id: string;
        label: string;
    }
}
declare module "_102029_/l2/bffClient" {
    import type { AuraInteractionMode, AuraNormalizedError } from '_102029_/l2/contracts/bootstrap';
    export interface BffClientOptions {
        mode?: AuraInteractionMode;
        timeoutMs?: number;
        signal?: AbortSignal;
    }
    export interface BffClientResponse<TData = unknown> {
        ok: boolean;
        data: TData | null;
        error: AuraNormalizedError | null;
    }
    export function execBff<TData = unknown>(routine: string, params: unknown, options?: BffClientOptions): Promise<BffClientResponse<TData>>;
}
declare module "_102029_/l2/collabLitElement.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102029_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102029_/l2/collabState.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102029_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102029_/l2/designSystem.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102029_/l2/designSystem" {
    import { IDesignSystemTokens } from '_102029_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
declare module "_102029_/l2/designSystemBase" {
    export interface IKeyValueToken {
        [key: string]: string;
    }
    export interface IDesignSystemTokens {
        themeName: string;
        description: string;
        color: IKeyValueToken;
        typography: IKeyValueToken;
        global: IKeyValueToken;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
}
declare module "_102029_/l2/interactionRuntime" {
    import type { AuraInteractionMode, AuraInteractionState, AuraNormalizedError } from '_102029_/l2/contracts/bootstrap';
    type InteractionListener = (state: AuraInteractionState) => void;
    interface BlockingActionOptions {
        mode?: AuraInteractionMode;
        timeoutMs?: number;
        clearContentWhileBusy?: boolean;
        busyLabel?: string;
        retry?: () => Promise<unknown> | unknown;
        errorTitle?: string;
    }
    interface PendingNavigationLoad {
        consumed: boolean;
        promise: Promise<void>;
        resolve: () => void;
        reject: (error: unknown) => void;
        signal?: AbortSignal;
    }
    export function getInteractionState(): AuraInteractionState;
    export function subscribeToInteractionState(listener: InteractionListener): () => void;
    export function clearBlockingError(): void;
    export function normalizeInteractionError(error: unknown): AuraNormalizedError;
    export function retryBlockingError(): Promise<void>;
    export function beginExpectedNavigationLoad(signal?: AbortSignal): Promise<void>;
    export function consumeExpectedNavigationLoad(): PendingNavigationLoad;
    export function bindExpectedNavigationLoad(pending: PendingNavigationLoad | null, promise: Promise<unknown>): void;
    export function runBlockingUiAction<T>(action: (signal: AbortSignal) => Promise<T>, options?: BlockingActionOptions): Promise<T | undefined>;
}
declare module "_102029_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102029_/l2/shellEvents" {
    export const AURA_TOGGLE_ASIDE_EVENT = "collab-aura:toggle-aside";
    export const AURA_OPEN_ASIDE_EVENT = "collab-aura:open-aside";
    export const AURA_CLOSE_ASIDE_EVENT = "collab-aura:close-aside";
    export function toggleAuraAside(): void;
    export function openAuraAside(): void;
    export function closeAuraAside(): void;
}
declare module "_102029_/l2/stateLitElement.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102029_/l2/stateLitElement" {
    import { PropertyValueMap } from 'lit';
    import { CollabLitElement } from '_102029_/l2/collabLitElement';
    /**
     * Base class for all components that need to interact with the shared state.
     */
    export abstract class StateLitElement extends CollabLitElement {
        stateKeys: Map<string, boolean>;
        updateStateKeys(attributeName: string, paths: string[]): void;
        private subscribeToState;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(_changedProperties: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        updated(_changedProps: PropertyValueMap<any> | Map<PropertyKey, unknown>): void;
        /**
         * Handle state changes from IcaState.
         * @param key - The state key that changed, ex: 'users[0].name'
         * @param value - The new value of the state.
         */
        handleIcaStateChange(key: string, value: any): void;
        connectMonitoring(): void;
    }
}
declare module "_102029_/l2/storageAdapter.test" {
    import { ICANTest, ICANIntegration } from '_100554_/l2/tsTestAST';
    export const integrations: ICANIntegration[];
    export const tests: ICANTest[];
}
declare module "_102029_/l2/storageAdapter" {
    export interface StorageAdapter {
        getTask(taskId: string): Promise<any>;
        getMessage(messageId: string): Promise<any>;
        addOrUpdateTask(task: any): Promise<void>;
        addPooling(pooling: any): Promise<void>;
        deletePooling(taskId: string): Promise<void>;
        updateThreadPendingTasks(threadId: string, taskId?: string): Promise<any>;
    }
    export function setStorageAdapter(adapter: StorageAdapter): void;
    export const storage: {
        getTask: (taskId: string) => Promise<any>;
        getMessage: (messageId: string) => Promise<any>;
        addOrUpdateTask: (task: any) => Promise<void>;
        addPooling: (pooling: any) => Promise<void>;
        deletePooling: (taskId: string) => Promise<void>;
        updateThreadPendingTasks: (threadId: string, taskId?: string) => Promise<any>;
    };
}
declare module "_102029_/l2/webCrypto" {
    export function createRuntimeUuid(): string;
    export function fillRandomBytes(bytes: Uint8Array): Uint8Array;
    export function sha256Hex(input: string): Promise<string>;
}
declare module "_102029_/l2/uuidv7" {
    export function createUuidV7(): string;
}
declare module "_102029_/l2/contracts/bootstrap" {
    export type AuraShellMode = 'spa' | 'pwa';
    export type AuraDeviceKind = 'desktop' | 'mobile';
    export type AuraAsideMode = 'inline' | 'drawer' | 'fullscreen';
    export interface AuraRegionVisibility {
        header: boolean;
        aside: boolean;
        content: boolean;
    }
    export interface AuraLayoutConfig {
        regions: {
            desktop: AuraRegionVisibility;
            mobile: AuraRegionVisibility;
        };
        asideMode: {
            desktop: AuraAsideMode;
            mobile: AuraAsideMode;
        };
    }
    export interface AuraRegionRendererConfig {
        entrypoint: string;
        tag: string;
    }
    export type AuraRouteMatchMode = 'exact' | 'prefix';
    export interface AuraRouteDefinition {
        path: string;
        entrypoint: string;
        tag: string;
        title: string;
        aliases?: string[];
        loadingKey?: string;
        preload?: boolean;
        matchMode?: AuraRouteMatchMode;
    }
    export interface AuraModuleFrontendDefinition {
        pageTitle?: string;
        device?: AuraDeviceKind;
        navigation?: AuraNavigationItem[];
        routes: AuraRouteDefinition[];
        headerRenderer?: AuraRegionRendererConfig;
        asideRenderer?: AuraRegionRendererConfig;
    }
    export interface AuraNavigationItem {
        id: string;
        label: string;
        href: string;
        description?: string;
    }
    export interface AuraModuleShellPreferences {
        layout?: Partial<AuraLayoutConfig>;
    }
    export interface AuraBootConfig {
        projectId: string;
        moduleId: string;
        basePath: string;
        shellMode: AuraShellMode;
        device: AuraDeviceKind;
        routes: AuraRouteDefinition[];
        headerEntrypoint?: string;
        headerTag?: string;
        asideEntrypoint?: string;
        asideTag?: string;
        pageTitle?: string;
        navigation?: AuraNavigationItem[];
        moduleLinks?: AuraNavigationItem[];
        layout: AuraLayoutConfig;
    }
    export type AuraInteractionMode = 'blocking' | 'silent';
    export type AuraBusyPhase = 'idle' | 'subtle' | 'dimmed';
    export interface AuraNormalizedError {
        code: string;
        message: string;
        details?: unknown;
    }
    export interface AuraBlockingErrorState {
        title: string;
        error: AuraNormalizedError;
        canRetry: boolean;
    }
    export interface AuraInteractionState {
        busy: boolean;
        busyPhase: AuraBusyPhase;
        busyLabel?: string;
        clearContentWhileBusy: boolean;
        blockingError?: AuraBlockingErrorState;
    }
    global {
        interface Window {
            collabAuraShellControls?: {
                toggleAside: () => void;
                openAside: () => void;
                closeAside: () => void;
            };
        }
        interface Window {
            collabBoot?: AuraBootConfig;
            collabRouteChunkCache?: Set<string>;
            collabRouteChunkPromises?: Map<string, Promise<unknown>>;
            collabAuraInteractionState?: AuraInteractionState;
            isTraceLazy?: boolean;
        }
    }
}
