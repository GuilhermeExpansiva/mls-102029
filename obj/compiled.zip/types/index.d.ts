declare module "_102029_/l2/designSystemBase" {
    import { IDesignSystemTokens } from '_102027_/l2/designSystemBase';
    export const tokens: IDesignSystemTokens[];
}
